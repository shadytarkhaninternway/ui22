import { motion } from "framer-motion";

interface PasswordStrengthIndicatorProps {
  password: string;
}

export default function PasswordStrengthIndicator({ password }: PasswordStrengthIndicatorProps) {
  const getStrength = (pwd: string) => {
    if (!pwd) return { level: 0, text: "", color: "" };
    
    let strength = 0;
    if (pwd.length >= 8) strength++;
    if (/[a-z]/.test(pwd) && /[A-Z]/.test(pwd)) strength++;
    if (/\d/.test(pwd)) strength++;
    if (/[^a-zA-Z0-9]/.test(pwd)) strength++;
    
    if (strength <= 1) return { level: 25, text: "Weak", color: "bg-destructive" };
    if (strength === 2) return { level: 50, text: "Fair", color: "bg-yellow-500" };
    if (strength === 3) return { level: 75, text: "Good", color: "bg-chart-2" };
    return { level: 100, text: "Strong", color: "bg-chart-3" };
  };

  const strength = getStrength(password);

  if (!password) return null;

  return (
    <div className="space-y-2">
      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
        <motion.div
          className={`h-full ${strength.color}`}
          initial={{ width: 0 }}
          animate={{ width: `${strength.level}%` }}
          transition={{ duration: 0.3 }}
        />
      </div>
      <p className="text-xs text-muted-foreground">
        Password strength: <span className="font-medium text-foreground">{strength.text}</span>
      </p>
    </div>
  );
}
