import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { User, Mail, Lock, Building2, GraduationCap, Briefcase, ArrowRight, Calendar, MapPin, Phone, Globe } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import FloatingShapes from "./FloatingShapes";
import AnimatedInput from "./AnimatedInput";
import RoleSelector, { UserRole } from "./RoleSelector";
import PasswordStrengthIndicator from "./PasswordStrengthIndicator";
import MultiSelectTags from "./MultiSelectTags";
import CVUploadZone from "./CVUploadZone";
import Navbar from "./Navbar";

export default function SignUpPage() {
  const [role, setRole] = useState<UserRole>("student");
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    university: "",
    college: "",
    degree: "",
    major: "",
    graduationYear: "",
    expertise: [] as string[],
    experience: "",
    jobTitle: "",
    linkedIn: "",
    companyName: "",
    industry: "",
    location: "",
    phone: "",
    address: "",
    description: "",
  });
  const [cvFile, setCvFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const expertiseSuggestions = [
    "Web Development", "Mobile Development", "AI/ML", "Data Science",
    "DevOps", "Cloud Computing", "UI/UX Design", "Cybersecurity"
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    console.log('Sign up data:', { role, formData, cvFile });

    setTimeout(() => {
      setIsLoading(false);
      console.log('Sign up successful');
    }, 2000);
  };

  const updateFormData = (key: string, value: any) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const getRoleIcon = () => {
    switch (role) {
      case "student": return GraduationCap;
      case "mentor": return Briefcase;
      case "company": return Building2;
    }
  };

  const RoleIcon = getRoleIcon();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 relative overflow-hidden">
      <Navbar />
      <FloatingShapes />

      <div className="relative z-10 min-h-screen py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-10"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-2xl mb-4">
              <RoleIcon className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-3">
              Create Account
            </h1>
            <p className="text-lg text-muted-foreground">
              Join our platform as a {role}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-card/50 backdrop-blur-xl border border-card-border rounded-3xl p-8 md:p-10 shadow-2xl"
          >
            <form onSubmit={handleSubmit} className="space-y-8">
              <div>
                <Label className="text-base font-medium text-foreground mb-3 block">
                  Select Account Type
                </Label>
                <RoleSelector selectedRole={role} onRoleChange={setRole} />
              </div>

              <div className="h-px bg-border" />

              <div className="space-y-6">
                <h3 className="text-lg font-heading font-semibold text-foreground">
                  Basic Information
                </h3>

                <div className="grid md:grid-cols-2 gap-6">
                  <AnimatedInput
                    label="Full Name"
                    icon={User}
                    placeholder="John Doe"
                    value={formData.fullName}
                    onChange={(v) => updateFormData("fullName", v)}
                    required
                    name="fullName"
                  />
                  <AnimatedInput
                    label="Email Address"
                    type="email"
                    icon={Mail}
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={(v) => updateFormData("email", v)}
                    required
                    name="email"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <AnimatedInput
                      label="Password"
                      type="password"
                      icon={Lock}
                      placeholder="Min. 8 characters"
                      value={formData.password}
                      onChange={(v) => updateFormData("password", v)}
                      required
                      name="password"
                    />
                    {formData.password && (
                      <div className="mt-3">
                        <PasswordStrengthIndicator password={formData.password} />
                      </div>
                    )}
                  </div>
                  <AnimatedInput
                    label="Confirm Password"
                    type="password"
                    icon={Lock}
                    placeholder="Re-enter password"
                    value={formData.confirmPassword}
                    onChange={(v) => updateFormData("confirmPassword", v)}
                    required
                    name="confirmPassword"
                  />
                </div>
              </div>

              <AnimatePresence mode="wait">
                <motion.div
                  key={role}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="h-px bg-border" />

                  {role === "student" && (
                    <>
                      <h3 className="text-lg font-heading font-semibold text-foreground">
                        Academic Details
                      </h3>

                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label className="text-sm font-medium">University</Label>
                          <Select value={formData.university} onValueChange={(v) => updateFormData("university", v)}>
                            <SelectTrigger className="h-11" data-testid="select-university">
                              <SelectValue placeholder="Select university" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="stanford">Stanford University</SelectItem>
                              <SelectItem value="mit">MIT</SelectItem>
                              <SelectItem value="harvard">Harvard University</SelectItem>
                              <SelectItem value="berkeley">UC Berkeley</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <AnimatedInput
                          label="College"
                          icon={Building2}
                          placeholder="e.g., Engineering"
                          value={formData.college}
                          onChange={(v) => updateFormData("college", v)}
                          name="college"
                        />
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <AnimatedInput
                          label="Degree"
                          icon={GraduationCap}
                          placeholder="e.g., B.Tech"
                          value={formData.degree}
                          onChange={(v) => updateFormData("degree", v)}
                          name="degree"
                        />
                        <AnimatedInput
                          label="Major"
                          icon={GraduationCap}
                          placeholder="e.g., Computer Science"
                          value={formData.major}
                          onChange={(v) => updateFormData("major", v)}
                          required
                          name="major"
                        />
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Graduation Year</Label>
                          <div className="relative">
                            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground z-10" />
                            <Input
                              type="number"
                              placeholder="2025"
                              value={formData.graduationYear}
                              onChange={(e) => updateFormData("graduationYear", e.target.value)}
                              className="pl-10 h-11"
                              min="2020"
                              max="2030"
                              data-testid="input-graduation-year"
                            />
                          </div>
                        </div>
                      </div>

                      <CVUploadZone
                        onFileUpload={(file) => setCvFile(file)}
                        onFileRemove={() => setCvFile(null)}
                      />
                    </>
                  )}

                  {role === "mentor" && (
                    <>
                      <h3 className="text-lg font-heading font-semibold text-foreground">
                        Professional Details
                      </h3>

                      <MultiSelectTags
                        label="Field of Expertise"
                        placeholder="Type to add expertise..."
                        value={formData.expertise}
                        onChange={(v) => updateFormData("expertise", v)}
                        suggestions={expertiseSuggestions}
                      />

                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Years of Experience</Label>
                          <Input
                            type="number"
                            placeholder="5"
                            value={formData.experience}
                            onChange={(e) => updateFormData("experience", e.target.value)}
                            className="h-11"
                            min="0"
                            data-testid="input-experience"
                          />
                        </div>
                        <AnimatedInput
                          label="Job Title"
                          icon={Briefcase}
                          placeholder="e.g., Senior Developer"
                          value={formData.jobTitle}
                          onChange={(v) => updateFormData("jobTitle", v)}
                          name="jobTitle"
                        />
                      </div>

                      <AnimatedInput
                        label="LinkedIn / Profile URL"
                        icon={Globe}
                        placeholder="https://linkedin.com/in/..."
                        value={formData.linkedIn}
                        onChange={(v) => updateFormData("linkedIn", v)}
                        name="linkedIn"
                      />
                    </>
                  )}

                  {role === "company" && (
                    <>
                      <h3 className="text-lg font-heading font-semibold text-foreground">
                        Company Information
                      </h3>

                      <div className="grid md:grid-cols-2 gap-6">
                        <AnimatedInput
                          label="Company Name"
                          icon={Building2}
                          placeholder="Acme Inc."
                          value={formData.companyName}
                          onChange={(v) => updateFormData("companyName", v)}
                          required
                          name="companyName"
                        />
                        <AnimatedInput
                          label="Industry"
                          icon={Briefcase}
                          placeholder="e.g., Technology"
                          value={formData.industry}
                          onChange={(v) => updateFormData("industry", v)}
                          name="industry"
                        />
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <AnimatedInput
                          label="Location"
                          icon={MapPin}
                          placeholder="City, Country"
                          value={formData.location}
                          onChange={(v) => updateFormData("location", v)}
                          name="location"
                        />
                        <AnimatedInput
                          label="Phone Number"
                          icon={Phone}
                          placeholder="+1 234 567 8900"
                          value={formData.phone}
                          onChange={(v) => updateFormData("phone", v)}
                          name="phone"
                        />
                      </div>

                      <AnimatedInput
                        label="Address"
                        icon={MapPin}
                        placeholder="Street address"
                        value={formData.address}
                        onChange={(v) => updateFormData("address", v)}
                        name="address"
                      />

                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Company Description</Label>
                        <Textarea
                          placeholder="Tell us about your company..."
                          value={formData.description}
                          onChange={(e) => updateFormData("description", e.target.value)}
                          className="min-h-[100px] resize-none"
                          maxLength={500}
                          data-testid="textarea-description"
                        />
                        <p className="text-xs text-muted-foreground text-right">
                          {formData.description.length}/500
                        </p>
                      </div>
                    </>
                  )}
                </motion.div>
              </AnimatePresence>

              <div className="pt-6">
                <Button
                  type="submit"
                  size="lg"
                  className="w-full h-12 text-base font-medium group"
                  disabled={isLoading}
                  data-testid="button-signup"
                >
                  {isLoading ? (
                    "Creating Account..."
                  ) : (
                    <>
                      Create Account
                      <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </Button>

                <div className="text-center mt-6">
                  <p className="text-sm text-muted-foreground">
                    Already have an account?{" "}
                    <Link href="/login" className="text-primary font-medium hover:underline" data-testid="link-login">
                      Sign In
                    </Link>
                  </p>
                </div>
              </div>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
}