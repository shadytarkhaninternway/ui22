import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, FileText, CheckCircle2, X, Loader2 } from "lucide-react";
import { Label } from "@/components/ui/label";

interface CVUploadZoneProps {
  onFileUpload?: (file: File) => void;
  onFileRemove?: () => void;
}

export default function CVUploadZone({ onFileUpload, onFileRemove }: CVUploadZoneProps) {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File) => {
    const validTypes = [
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/msword",
    ];
    
    if (!validTypes.includes(file.type)) {
      setError("Only PDF and DOCX files are accepted");
      return false;
    }
    
    if (file.size > 5 * 1024 * 1024) {
      setError("File size must be less than 5MB");
      return false;
    }
    
    return true;
  };

  const handleFile = (selectedFile: File) => {
    setError("");
    
    if (!validateFile(selectedFile)) {
      return;
    }

    setIsUploading(true);
    
    setTimeout(() => {
      setFile(selectedFile);
      setIsUploading(false);
      if (onFileUpload) onFileUpload(selectedFile);
    }, 1500);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) handleFile(droppedFile);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) handleFile(selectedFile);
  };

  const removeFile = () => {
    setFile(null);
    setError("");
    if (fileInputRef.current) fileInputRef.current.value = "";
    if (onFileRemove) onFileRemove();
  };

  return (
    <div className="space-y-3">
      <Label className="text-sm font-medium text-foreground">Upload CV</Label>
      
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-2xl transition-all ${
          isDragging
            ? "border-primary bg-primary/5"
            : file
            ? "border-chart-3 bg-chart-3/5"
            : error
            ? "border-destructive bg-destructive/5"
            : "border-border bg-muted/30"
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          onChange={handleFileInput}
          accept=".pdf,.doc,.docx"
          className="hidden"
          data-testid="input-cv-upload"
        />

        <AnimatePresence mode="wait">
          {isUploading ? (
            <motion.div
              key="uploading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="p-8 text-center"
            >
              <Loader2 className="w-12 h-12 mx-auto text-primary animate-spin" />
              <p className="mt-4 text-sm text-muted-foreground">Processing your CV...</p>
            </motion.div>
          ) : file ? (
            <motion.div
              key="uploaded"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="p-6"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 bg-chart-3/10 rounded-xl">
                  <FileText className="w-6 h-6 text-chart-3" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">{file.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {(file.size / 1024).toFixed(1)} KB
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-chart-3" />
                      <button
                        onClick={removeFile}
                        className="p-1 rounded-md hover-elevate"
                        data-testid="button-remove-cv"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.button
              key="upload"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => fileInputRef.current?.click()}
              className="w-full p-8 text-center hover-elevate transition-all"
              type="button"
              data-testid="button-upload-cv"
            >
              <Upload className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="font-medium text-foreground mb-1">
                Drop your CV here or click to browse
              </p>
              <p className="text-sm text-muted-foreground">PDF or DOCX, up to 5MB</p>
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      {error && (
        <motion.p
          initial={{ opacity: 0, y: -5 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-sm text-destructive"
        >
          {error}
        </motion.p>
      )}
    </div>
  );
}
