import { motion } from "framer-motion";

export default function FloatingShapes() {
  const shapes = [
    { size: 80, x: "10%", y: "20%", delay: 0, color: "from-primary/20 to-primary/5" },
    { size: 120, x: "80%", y: "60%", delay: 2, color: "from-chart-2/20 to-chart-2/5" },
    { size: 60, x: "70%", y: "10%", delay: 1, color: "from-primary/15 to-transparent" },
    { size: 100, x: "15%", y: "70%", delay: 3, color: "from-chart-2/25 to-chart-2/10" },
    { size: 50, x: "90%", y: "30%", delay: 1.5, color: "from-primary/10 to-transparent" },
  ];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {shapes.map((shape, i) => (
        <motion.div
          key={i}
          className={`absolute rounded-full bg-gradient-to-br ${shape.color} blur-xl`}
          style={{
            width: shape.size,
            height: shape.size,
            left: shape.x,
            top: shape.y,
          }}
          animate={{
            y: [0, -30, 0],
            x: [0, 15, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            delay: shape.delay,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}
