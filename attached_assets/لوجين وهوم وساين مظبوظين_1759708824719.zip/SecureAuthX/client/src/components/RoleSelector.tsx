import { motion } from "framer-motion";
import { GraduationCap, Briefcase, Building2 } from "lucide-react";

export type UserRole = "student" | "mentor" | "company";

interface RoleSelectorProps {
  selectedRole: UserRole;
  onRoleChange: (role: UserRole) => void;
}

const roles = [
  { value: "student" as UserRole, label: "Student", icon: GraduationCap },
  { value: "mentor" as UserRole, label: "Mentor", icon: Briefcase },
  { value: "company" as UserRole, label: "Company", icon: Building2 },
];

export default function RoleSelector({ selectedRole, onRoleChange }: RoleSelectorProps) {
  return (
    <div className="relative bg-muted/50 rounded-2xl p-1.5 grid grid-cols-3 gap-1.5">
      {roles.map((role) => {
        const Icon = role.icon;
        const isSelected = selectedRole === role.value;
        
        return (
          <button
            key={role.value}
            onClick={() => onRoleChange(role.value)}
            className="relative z-10 px-4 py-3 rounded-xl transition-colors"
            data-testid={`button-role-${role.value}`}
          >
            {isSelected && (
              <motion.div
                layoutId="role-selector"
                className="absolute inset-0 bg-primary rounded-xl"
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              />
            )}
            <div className="relative flex flex-col items-center gap-1.5">
              <Icon className={`w-5 h-5 transition-colors ${isSelected ? "text-primary-foreground" : "text-muted-foreground"}`} />
              <span className={`text-sm font-medium transition-colors ${isSelected ? "text-primary-foreground" : "text-foreground"}`}>
                {role.label}
              </span>
            </div>
          </button>
        );
      })}
    </div>
  );
}
