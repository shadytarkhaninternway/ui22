import CVUploadZone from '../CVUploadZone';

export default function CVUploadZoneExample() {
  return (
    <div className="w-full max-w-md p-8">
      <CVUploadZone
        onFileUpload={(file) => console.log('File uploaded:', file.name)}
        onFileRemove={() => console.log('File removed')}
      />
    </div>
  );
}
