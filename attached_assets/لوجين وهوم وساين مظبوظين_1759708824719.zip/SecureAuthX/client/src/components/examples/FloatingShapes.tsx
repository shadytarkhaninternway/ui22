import FloatingShapes from '../FloatingShapes';

export default function FloatingShapesExample() {
  return <FloatingShapes />;
}
