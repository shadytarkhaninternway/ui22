import AnimatedInput from '../AnimatedInput';
import { Mail } from 'lucide-react';

export default function AnimatedInputExample() {
  return (
    <div className="w-full max-w-md p-8">
      <AnimatedInput
        label="Email Address"
        type="email"
        icon={Mail}
        placeholder="your@email.com"
        name="email"
        required
      />
    </div>
  );
}
