import MultiSelectTags from '../MultiSelectTags';

export default function MultiSelectTagsExample() {
  const suggestions = [
    'JavaScript', 'TypeScript', 'React', 'Node.js', 'Python', 
    'Machine Learning', 'Web Development', 'Mobile Development'
  ];
  
  return (
    <div className="w-full max-w-md p-8">
      <MultiSelectTags
        label="Field of Expertise"
        placeholder="Type to search or add..."
        suggestions={suggestions}
      />
    </div>
  );
}
