import { useState } from 'react';
import PasswordStrengthIndicator from '../PasswordStrengthIndicator';
import { Input } from '@/components/ui/input';

export default function PasswordStrengthIndicatorExample() {
  const [password, setPassword] = useState('');
  
  return (
    <div className="w-full max-w-md p-8 space-y-4">
      <Input
        type="password"
        placeholder="Enter password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <PasswordStrengthIndicator password={password} />
    </div>
  );
}
