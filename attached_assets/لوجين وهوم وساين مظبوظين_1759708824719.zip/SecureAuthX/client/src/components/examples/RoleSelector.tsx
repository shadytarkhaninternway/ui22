import { useState } from 'react';
import RoleSelector, { UserRole } from '../RoleSelector';

export default function RoleSelectorExample() {
  const [role, setRole] = useState<UserRole>('student');
  
  return (
    <div className="w-full max-w-md p-8">
      <RoleSelector selectedRole={role} onRoleChange={setRole} />
    </div>
  );
}
