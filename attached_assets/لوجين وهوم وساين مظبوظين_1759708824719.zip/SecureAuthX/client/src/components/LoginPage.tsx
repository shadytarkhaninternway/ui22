import { useState } from "react";
import { motion } from "framer-motion";
import { Link, useLocation } from "wouter";
import { Mail, Lock, Briefcase, GraduationCap, Building2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import AnimatedInput from "./AnimatedInput";
import RoleSelector from "./RoleSelector";
import FloatingShapes from "./FloatingShapes";
import Navbar from "./Navbar";
import type { UserRole } from "@/lib/types";
export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<UserRole>("student");
  const [rememberMe, setRememberMe] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [isLoading, setIsLoading] = useState(false);

  const validateForm = () => {
    const newErrors: { email?: string; password?: string } = {};

    if (!email) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Invalid email format";
    }

    if (!password) {
      newErrors.password = "Password is required";
    } else if (password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    console.log('Login attempt:', { email, password, role, rememberMe });

    setTimeout(() => {
      setIsLoading(false);
      console.log('Login successful - redirecting to dashboard');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 relative overflow-hidden">
      <Navbar />
      <FloatingShapes />

      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="hidden lg:block"
          >
            <div className="relative">
              <motion.div
                className="w-full h-[500px] bg-gradient-to-br from-primary/20 to-chart-2/20 rounded-3xl flex items-center justify-center backdrop-blur-sm border border-primary/10"
                animate={{
                  scale: [1, 1.02, 1],
                  rotate: [0, 1, 0],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              >
                <div className="text-center space-y-6 p-8">
                  <motion.div
                    className="w-24 h-24 mx-auto bg-primary/20 rounded-full flex items-center justify-center"
                    animate={{
                      y: [0, -10, 0],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  >
                    <div className="w-16 h-16 bg-primary rounded-full" />
                  </motion.div>
                  <h2 className="text-4xl font-heading font-bold text-foreground">
                    Welcome Back!
                  </h2>
                  <p className="text-lg text-muted-foreground max-w-md mx-auto">
                    Connect with mentors, find opportunities, or discover talent on our platform
                  </p>
                </div>
              </motion.div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="w-full"
          >
            <div className="bg-card/50 backdrop-blur-xl border border-card-border rounded-3xl p-8 md:p-10 shadow-2xl">
              <div className="mb-8">
                <h1 className="text-3xl md:text-4xl font-heading font-bold text-foreground mb-2">
                  Sign In
                </h1>
                <p className="text-muted-foreground">
                  Enter your credentials to access your account
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <RoleSelector selectedRole={role} onRoleChange={setRole} />

                <AnimatedInput
                  label="Email Address"
                  type="email"
                  icon={Mail}
                  placeholder="your@email.com"
                  value={email}
                  onChange={setEmail}
                  error={errors.email}
                  required
                  name="email"
                />

                <AnimatedInput
                  label="Password"
                  type="password"
                  icon={Lock}
                  placeholder="Enter your password"
                  value={password}
                  onChange={setPassword}
                  error={errors.password}
                  required
                  name="password"
                />

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="remember"
                      checked={rememberMe}
                      onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                      data-testid="checkbox-remember-me"
                    />
                    <label
                      htmlFor="remember"
                      className="text-sm text-foreground cursor-pointer"
                    >
                      Remember me
                    </label>
                  </div>
                  <button
                    type="button"
                    className="text-sm text-primary hover:underline"
                    data-testid="link-forgot-password"
                  >
                    Forgot Password?
                  </button>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full h-12 text-base font-medium group"
                  disabled={isLoading}
                  data-testid="button-login"
                >
                  {isLoading ? (
                    "Signing In..."
                  ) : (
                    <>
                      Sign In
                      <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </Button>

                <div className="text-center">
                  <p className="text-sm text-muted-foreground">
                    Don't have an account?{" "}
                    <Link href="/signup" className="text-primary font-medium hover:underline" data-testid="link-signup">
                      Sign Up
                    </Link>
                  </p>
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}