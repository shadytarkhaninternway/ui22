# Design Guidelines: 3D Animated Multi-Role Authentication Platform

## Design Approach
Reference-based approach inspired by modern onboarding flows like Notion, Figma, and Dribbble with heavy emphasis on 3D animated elements, smooth transitions, and interactive micro-animations.

## Core Design Elements

### A. Color Palette
**Primary Colors:**
- Primary Blue: #007BFF (212 100% 56%)
- Secondary Background: #F5F7FA (220 20% 97%)
- Accent Blue: #4A90E2 (210 77% 59%)
- Light Accent: #EEF3FF (220 100% 97%)

**Supporting Colors:**
- Text Primary: #1A1A1A (0 0% 10%)
- Text Secondary: #6B7280 (220 9% 46%)
- Success: #10B981 (160 84% 39%)
- Error: #EF4444 (0 84% 60%)
- Borders: #E5E7EB (220 13% 91%)

### B. Typography
- **Primary Font:** Poppins (Headings, Bold weights)
- **Secondary Font:** Inter (Body, Regular/Medium)
- **Heading Sizes:** text-4xl to text-6xl (large, bold)
- **Body Text:** text-base to text-lg
- **Clear hierarchy with medium to bold weights**

### C. Layout System
**Spacing Units:** Tailwind units of 4, 6, 8, 12, 16, 20, 24
**Border Radius:** Consistent 16px (rounded-2xl) for cards and buttons
**Shadows:** Soft depth shadows with multi-layer approach for 3D effect

### D. Component Library

**Login Page:**
- Split-screen layout (50/50 desktop, stacked mobile)
- Left: 3D Lottie animation (teamwork/mentorship theme)
- Right: Floating card with glassmorphism effect
- Form fields: Email, Password, Role selection (radio buttons)
- Animated placeholders with inline icons
- Primary gradient button with hover motion
- "Forgot Password?" and "Sign Up" links

**Sign-Up Page:**
- Animated tab switcher for role selection (Student/Mentor/Company)
- Dynamic form fields with smooth slide/fade transitions
- Floating 3D icons near forms (graduation cap, briefcase, building)
- Card layout with soft background glow

**Common Form Elements:**
- Full Name, Email, Password, Confirm Password
- Real-time validation indicators
- Animated placeholders with icons (envelope, lock, user)
- Password strength meter with color-coded animation
- Match confirmation for password fields

**Student Fields:**
- University (dropdown with suggestions)
- College, Degree, Major (text/select inputs)
- Graduation Year (year picker)
- CV Upload with drag-drop zone
- Animated CV parsing with typewriter effect showing extracted data

**Mentor Fields:**
- Field of Expertise (multi-select with animated tag chips)
- Years of Experience (number input)
- Job Title, LinkedIn URL (text inputs)

**Company Fields:**
- Company Name, Industry, Location
- Contact Info (Email, Phone, Address)
- Social Media Icons (LinkedIn, Facebook)
- Company Description (textarea, 500 char limit)

**Interactive Elements:**
- Buttons: Gradient backgrounds, hover expansion, scale animations
- Inputs: Focus glow effects, floating labels
- Upload zones: Drag-drop states with visual feedback
- Progress indicators: Animated bars and checkmarks
- Error/Success modals: Fade-in with subtle bounce

### E. 3D & Animation Elements

**Background Animations:**
- Floating geometric shapes (spheres, cubes) with parallax scrolling
- Subtle gradient overlays with animated shifts
- Glassmorphism cards with backdrop blur

**Micro-interactions:**
- Button hover: Scale + gradient shift
- Input focus: Glow ring animation
- Tab switch: Slide + fade transition
- Form submission: Loading spinner to checkmark
- Invalid input: Shake animation
- CV upload: Progress bar to success state

**Page Transitions:**
- Fade-in on load
- Smooth slide between login/signup
- Role-specific form fields slide into view

**3D Visual Elements:**
- Lottie animations for hero illustrations
- SVG icons with depth and shadow
- Layered card effects with elevation
- Parallax background elements

## Images
No large hero images required. Instead, use:
- **3D Lottie animations** for login page left panel (teamwork/mentorship themed)
- **Animated SVG icons** for role selection (graduation cap, briefcase, building icon)
- **Small illustrative elements** within form sections for visual interest

## Responsive Behavior
- **Desktop:** Split-screen login, multi-column form layouts, full animations
- **Tablet:** Stacked sections, reduced animation complexity
- **Mobile:** Single column, simplified animations, touch-optimized inputs, full-width buttons

## Accessibility
- Consistent form labels and ARIA attributes
- Keyboard navigation support
- Focus states with visible indicators
- Color contrast meeting WCAG AA standards
- Screen reader-friendly error messages

## Key Principles
- **Interactive Intelligence:** Forms feel smart with real-time validation and contextual feedback
- **Smooth Fluidity:** All transitions use easing curves (ease-in-out, cubic-bezier)
- **Visual Depth:** Layered cards, shadows, and 3D elements create dimensional hierarchy
- **Professional Polish:** Clean, minimal aesthetic with purposeful animation—never gratuitous